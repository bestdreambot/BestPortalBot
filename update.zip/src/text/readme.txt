Тестовый проект BestPortalBot. Версия update.zip
