Static text holder for future notes.
